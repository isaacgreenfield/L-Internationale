import os

os.system('Verevka0.py')

os.system('Verevka0.py')

os.system('Verevka2.py')

os.system('Verevka3.py')

os.system('Verevka4.py')

os.system('Verevka5.py')

os.system('Verevka6.py')

os.system('Verevka7.py')

os.system('Verevka8.py')

os.system('Verevka8.py')

print("Fedoss")
